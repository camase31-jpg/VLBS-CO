let carrito = [];
let total = 0;

function agregarCarrito(producto, precio) {
  carrito.push({ producto, precio });
  total += precio;
  actualizarCarrito();
}

function actualizarCarrito() {
  const lista = document.getElementById('lista-carrito');
  lista.innerHTML = "";
  carrito.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.producto} - $${item.precio}`;
    lista.appendChild(li);
  });
  document.getElementById('total').textContent = total;
}